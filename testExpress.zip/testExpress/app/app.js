import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const WWWDIR = "public";
const LOGDIR = "logs";
const ERRDIR = "errors";

const app = express();

// Serve static files from /app/pages
app.use(express.static(path.join(__dirname, WWWDIR)));

// Example route for homepage
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, WWWDIR, "index.html"));
});

// 404 fallback
app.use((req, res) => {
  res.status(404).sendFile(path.join(__dirname, ERRDIR, "404.html"));
});

export default app;
