const dqs = document.querySelector.bind(document);

async function fetchData() {
  try {
    const response = await fetch(
      "https://raw.githubusercontent.com/LostInCanada/TestFetching/main/data.json",
    );

    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

    const data = await response.json();
    console.log(data); // [{ data_1: true }]

    // Example: Access first item's value
    console.log(data[0].data_1); // true
    return data;
  } catch (err) {
    console.error("Failed to fetch JSON:", err);
  }
  console.log("Completed");
}

const updateData = async () => {
  let boolVal = await fetchData();
  dqs("#lockedBool").textContent = boolVal[0].data_1;
  dqs("#lockedBool2").textContent = boolVal[1].data_2;
  dqs("#houseTemp").textContent = boolVal[2].data_3;
};

document.addEventListener("DOMContentLoaded", async () => {
  console.log("DOM loaded");
  await updateData();
  setInterval(updateData, 3000);
});
