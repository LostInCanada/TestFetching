import http from "http";
import app from "./app/app.js";

const PORT = 8888;

const server = http.createServer(app);

server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
